import os
import re
import string
import glob
import requests
import pandas as pd
from bs4 import BeautifulSoup
import spacy

#Here we will load spaCy model
nlp = spacy.load("en_core_web_sm")

#Here we will load Stop Words from all StopWords/*.txt
def load_stopwords(folder_path="StopWords"):
    stop_words = set()
    for file in glob.glob(os.path.join(folder_path, "*.txt")):
        with open(file, "r", encoding="ISO-8859-1") as f:
            stop_words.update([line.strip().lower() for line in f if line.strip()])
    return stop_words

#Here we will load Positive and Negative Words
def load_sentiment_words(pos_path, neg_path):
    with open(pos_path, "r") as f:
        positive_words = [line.strip().lower() for line in f if line.strip() and not line.startswith(";")]
    with open(neg_path, "r") as f:
        negative_words = [line.strip().lower() for line in f if line.strip() and not line.startswith(";")]
    return positive_words, negative_words

#Here we will clean the text
def clean_text(text):
    text = text.lower()
    text = re.sub(r'\s+', ' ', text)
    text = text.translate(str.maketrans('', '', string.punctuation))
    return text

#This is the syllable Count
def count_syllables(word):
    word = word.lower()
    count = len(re.findall(r'[aeiouy]+', word))
    if word.endswith(('es', 'ed')):
        count -= 1
    return max(count, 1)

def is_complex(word):
    return count_syllables(word) > 2

#This is the text analyzer using spaCy
def analyze_text(text, stop_words, pos_words, neg_words):
    cleaned_text = clean_text(text)
    doc = nlp(text)
    sentences = list(doc.sents)
    total_sentences = len(sentences)

    words = [token.text.lower() for token in doc if token.is_alpha and token.text.lower() not in stop_words]
    total_words = len(words)

    pos_score = sum(1 for w in words if w in pos_words)
    neg_score = sum(1 for w in words if w in neg_words)

    polarity = (pos_score - neg_score) / ((pos_score + neg_score) + 1e-6)
    subjectivity = (pos_score + neg_score) / (total_words + 1e-6)

    avg_sentence_len = total_words / total_sentences if total_sentences else 0
    complex_words = [w for w in words if is_complex(w)]
    percent_complex = len(complex_words) / total_words * 100 if total_words else 0
    fog_index = 0.4 * (avg_sentence_len + percent_complex)

    syllables_per_word = sum(count_syllables(w) for w in words) / total_words if total_words else 0
    pronouns = len([token.text for token in doc if token.text.lower() in ["i", "we", "my", "ours", "us"]])
    avg_word_len = sum(len(w) for w in words) / total_words if total_words else 0

    return {
        "POSITIVE SCORE": pos_score,
        "NEGATIVE SCORE": neg_score,
        "POLARITY SCORE": polarity,
        "SUBJECTIVITY SCORE": subjectivity,
        "AVG SENTENCE LENGTH": avg_sentence_len,
        "PERCENTAGE OF COMPLEX WORDS": percent_complex,
        "FOG INDEX": fog_index,
        "AVG NUMBER OF WORDS PER SENTENCE": avg_sentence_len,
        "COMPLEX WORD COUNT": len(complex_words),
        "WORD COUNT": total_words,
        "SYLLABLE PER WORD": syllables_per_word,
        "PERSONAL PRONOUNS": pronouns,
        "AVG WORD LENGTH": avg_word_len
    }

#This is the Main Script
def main():
    input_df = pd.read_excel("Input.xlsx")
    stop_words = load_stopwords("StopWords")
    pos_words, neg_words = load_sentiment_words("MasterDictionary/positive-words.txt",
                                                "MasterDictionary/negative-words.txt")

    results = []
    os.makedirs("extracted_articles", exist_ok=True)

    for _, row in input_df.iterrows():
        url_id = row["URL_ID"]
        url = row["URL"]

        try:
            res = requests.get(url, timeout=10)
            soup = BeautifulSoup(res.content, "html.parser")
            title = soup.find("h1").get_text(strip=True)
            article = ' '.join([p.get_text(strip=True) for p in soup.find_all("p")])
            full_text = f"{title}\n\n{article}"

            with open(f"extracted_articles/{url_id}.txt", "w", encoding="utf-8") as f:
                f.write(full_text)

            metrics = analyze_text(full_text, stop_words, pos_words, neg_words)
            output_row = row.to_dict()
            output_row.update(metrics)
            results.append(output_row)
            print(f"[✔] Processed {url_id}")

        except Exception as e:
            print(f"[✘] Failed for {url_id} — {e}")

    pd.DataFrame(results).to_excel("Blackcoffer_Final_Output.xlsx", index=False)
    print("\n All done! Output saved as 'Blackcoffer_Final_Output.xlsx'")

if __name__ == "__main__":
    main()
